<html>
	<head>
		<title>Icons</title>
		<link href="/multison/templates/wt_garden_pro/css/flaticon.css" rel="stylesheet" type="text/css">
		<link href="/multison/templates/wt_garden_pro/css/template.css" rel="stylesheet" type="text/css">
	</head>

	<body>

		<?php

			$lines = file('templates/wt_garden_pro/css/flaticon.css');

			$i = 0;

			foreach ($lines as $key => $value) {
				if ( ($i % 10) == 0) { 
					$break = "<br>";
				} else {
					$break = ''; 
				}

				$char = substr($value, 0, 1);
				
				if($char == '.'){
					$position = strpos($value, ':');
					$text = substr($value, 1, $position - 1);

					print('<span class="box-top wow fadeInUp" data-wow-duration="1.5s" data-wow-delay=".6s" style="visibility: visible; animation-duration: 1.5s; animation-delay: 0.6s; animation-name: fadeInUp;">');

					print('<i class="' . $text .  ' circle-white"></i>' . $break);

					print('</span>');
				}

				$i++;
			}

		?>

	</body>
</html>